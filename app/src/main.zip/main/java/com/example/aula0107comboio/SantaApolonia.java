package com.example.aula0107comboio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SantaApolonia extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_santa_apolonia);
        Intent alfaQueChega = getIntent();
        String cargaAReceber = alfaQueChega.getStringExtra("CARRUAGEM01");
        int cargaNumerica = alfaQueChega.getIntExtra("CARRUAGEM02",0);
        String cargaOla = alfaQueChega.getStringExtra("CARRUAGEM03");
        TextView tv = (TextView) findViewById(R.id.lblMensagem);
        tv.setText(cargaAReceber + " " + cargaNumerica + " " + cargaOla);
    }

    public void voltarPrincipal (View v) {
        this.finish();
    }
}