package com.example.aula0107comboio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void enviarMensagem(View v){
        Intent alfa = new Intent(this, SantaApolonia.class);
        EditText txtCarga = (EditText) findViewById(R.id.txtMensagem);
        String cargaAEnviar = txtCarga.getText().toString();
        alfa.putExtra("CARRUAGEM01", cargaAEnviar);
        alfa.putExtra("CARRUAGEM02", 397);
        alfa.putExtra("CARRUAGEM03", "Ola, isto é um teste");
        startActivity(alfa);
    }

    @Override
    protected void onResume() {
        super.onResume();
        EditText et = (EditText) findViewById(R.id.txtMensagem);
        et.setText("");
    }
}